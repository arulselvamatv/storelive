<?php

require_once("../database/connect.php");
$db=new Database;
$con=$db->connect();

$wo_no=$_GET['wo_no'];
$quo_no=$_GET['quo_no'];
$HTML="";
	if($con)
	{
		echo '<thead>
		<tr>
		  <th class="text-center">No</th>
          <th class="text-center">Quotation NO</th>
          <th class="text-center">Work Order NO</th>
		  <th class="text-center">Product Name</th>
		  <th class="text-center">Quantity</th>
		  <th class="text-center">Specification needed</th>';
		  
				$asd =('SELECT s.company_name,s.name, qsa.`suplier_id` FROM `quot_sup_amt_sel` as qsa
                inner join suplier as s on s.sup_id= qsa.suplier_id
                WHERE `wo_no`="'.$wo_no.'" and qsa.active_record =1 group by suplier_id');
				//echo $asd; exit;
				$datd = $db->query($asd);
				while($data=$datd->fetch(PDO::FETCH_ASSOC))
					{
						echo "<th class='text-center'>".''.$data['company_name']."<input type='hidden' name='sup_name[]' id='sup_name_".$i."' value='".$data['suplier_id']."' /></th>";
					}

					echo '<th class="text-center">Edit</th></tr>
	  </thead>
	  <tbody id="tbody">';

	  
		
		
		$asd =('SELECT `qas_id`, `wo_no`, `suplier_id`, `quo_no`, `prod_name`, `ddl_pro_qty`, `ddl_pro_unit`, `product_spec`, `suplier_amt`, `disc_amt`, `gst_amt`, `tot`, `check_no`, `date_time`, `po_status`, `active_record` FROM `quot_sup_amt_sel` WHERE `wo_no`="'.$wo_no.'" and active_record=1 group by prod_name');
		//echo $asd; exit;
		$i=0;
		$prdt_data = $db->query($asd);
		while($prd = $prdt_data->fetch(PDO::FETCH_ASSOC))
		{
			$product_name =$prd['prod_name'];
			$check_no =$prd['check_no'];
			$i = ++$i;
			echo '<tr>'.
			'<th>'.$i.'.</th>'.
            '<th>'.
			'<input class="form-control" name="quo_no[]" id="quo_no'.$i.'" value="'.$prd['quo_no'].'" readonly="readonly" />'.
			'</th>'.
            '<th>'.
			'<input class="form-control" name="wo_no[]" id="wo_no'.$i.'" value="'.$prd['wo_no'].'" readonly="readonly" />'.
			'</th>'.
			'<th>'.
			'<input class="form-control" name="prod_name[]" id='.$i.' value="'.$prd['prod_name'].'" readonly="readonly" />'.
			'</th>'.
			'<th>'.
			'<input class="form-control" name="ddl_pro_unt[]" id="iunt_'.$i.'" value="Per '.$prd['ddl_pro_unit'].'" readonly="readonly" />
            <input type="hidden"class="form-control" name="ddl_pro_unit[]" id="iunit_'.$i.'" value="'.$prd['ddl_pro_unit'].'" readonly="readonly" />
            <input type="hidden"class="form-control" name="ddl_pro_qty[]" id="iqty_'.$i.'" value="'.$prd['ddl_pro_qty'].'" readonly="readonly" /></th>'.
			'<th><input class="form-control" name="ddl_pro_spec[]" id="ispec_'.$i.'" value="'.$prd['product_spec'].'" readonly="readonly" />'.
			'</th>';
            echo '<th>';
			
            
            echo '<input type="hidden" name="sup_id[]" id="sup_id_'.$i.'" value="'.$prd['suplier_id'].'" readonly="readonly" />
            Supplier Amount:<input class="form-control sup_amts" name="sup_amt[]" id="sup_amt_'.$i.'" value="'.$prd['suplier_amt'].'" readonly="readonly" />
			Discount %:<input class="form-control disc_amt" name="disc_amt[]" id="disc_amt_'.$i.'" value="'.$prd['disc_amt'].'" readonly="readonly" />
			GST %:<input class="form-control gst_amt" name="gst_amt[]" id="gst_amt_'.$i.'" value="'.$prd['gst_amt'].'" readonly="readonly" />
			Total:';
            $bill_value= $prd['suplier_amt'] * $prd['ddl_pro_qty'];
			$tmp_disc=($bill_value*$prd['disc_amt']/100);
			$gst=(($bill_value-$tmp_disc)*$prd['gst_amt']/100);
			$total_value=$bill_value-$tmp_disc+$gst;

            echo '<input  name="tot_val[]" id="tot_val_'.$i.'" class="form-control" value="'.$total_value.'" readonly="readonly"/><input type="hidden" name="tot[]" id="tot_'.$i.'" class="form-control" value="'.$prd['tot'].'" readonly="readonly"/>';
               
            echo '</th>';
            echo '<th><input type="button" class="btn btn-primary edits" name="edit-button[]" id="edit-button_'.$i.'" value="Edit" />
			<input type="button" class="btn btn-primary done" name="end-editing[]" id="end-editing_'.$i.'" value="Done" style="visibility:hidden" /></th>';
			echo '</tr>';
		}
        echo "
        <tr><th>
      
        Terms and Conditions:<input class='form-control' type='text' id='term_cond' name='term_cond' required/>
        </th>
        <th>
        Remarks:<input class='form-control' type='text' id='remarks' name='remarks' required/>
        
        </th>
        </tr>

        <tr><th>
        <div class='col-sm-12'>
                                                    
        <center>
      
        <input class='btn btn-success' type='submit' value='Create PO'>&nbsp;
        
        </center>
        
        </div>
        </th>
        <th>
        <div class='col-sm-12'>
                                                    
        <center>
      
        <input class='btn btn-danger'  type='button' value='Cancel' onClick='window.location.reload();'>
        
        </center>
        
        </div>
        
        </th>
        </tr>";
		echo '</tbody>';
        
		
	}
    

	
	    
?>
<script src="../../assets/node_modules/jquery/dist/jquery.min.js"></script>


<link href="../assets/global/plugins/select2/css/select2.min.css" rel="stylesheet" />
<script src="../assets/global/plugins/select2/js/select2.min.js"></script>
<script>
    $( document ).ready(function() {
            $( '.chk' ).each(function( index ) {

                var this_attr_id = $.trim($(this).attr("id"));
                var splt_this_id = this_attr_id.split("_");
                var splt_this_id_ar = splt_this_id[1];
                if ($('#iqty_'+splt_this_id_ar).val()<=0) {
                    //prevent the default form submit if it is not checked
                    alert("Plz select atleast one quantity to submit");
                    e.preventDefault();
                    }
           
        });

    // ON keyup disc_amt
    $(document).on('keyup', '.disc_amt', function( e ) {
                var this_attr_id = $.trim($(this).attr("id"));
                var splt_this_id = this_attr_id.split("_");
                var splt_this_id_ar = splt_this_id[2];

                var disc = $('#disc_amt_'+splt_this_id_ar).val();
                var price = $('#sup_amt_'+splt_this_id_ar).val();
                var prices = $('#sup_amt_'+splt_this_id_ar).val()*$('#iqty_'+splt_this_id_ar).val();
                var dec = (disc / 100).toFixed(2); //its convert 10 into 0.10
                //alert(dec);
                var mult = price * dec;
                var mults = prices * dec; // gives the value for subtract from main value
                var discount = price - mult;
                var discounts = prices - mults;
                
                var gst = $('#gst_amt_'+splt_this_id_ar).val();
                var tot_price = Number(discount * gst / 100) + Number(discount);
                var tot_prices = Number(discounts * gst / 100) + Number(discounts);
                // alert(disc); exit;
                
                $('#tot_'+splt_this_id_ar).val(tot_price);
                $('#tot_val_'+splt_this_id_ar).val(tot_prices);
                });
                // ON keyup disc_amt END
                // ON keyup gst_amt
                
                $(document).on('keyup', '.gst_amt', function( e ) {
                var this_attr_id = $.trim($(this).attr("id"));
                var splt_this_id = this_attr_id.split("_");
                var splt_this_id_ar = splt_this_id[2];

                var disc = $('#disc_amt_'+splt_this_id_ar).val();
                var price = $('#sup_amt_'+splt_this_id_ar).val();
                var prices = $('#sup_amt_'+splt_this_id_ar).val()*$('#iqty_'+splt_this_id_ar).val();
                var dec = (disc / 100).toFixed(2); //its convert 10 into 0.10
                //alert(dec);
                var mult = price * dec;
                var mults = prices * dec; // gives the value for subtract from main value
                var discount = price - mult;
                var discounts = prices - mults;
                
                var gst = $('#gst_amt_'+splt_this_id_ar).val();
                var tot_price = Number(discount * gst / 100) + Number(discount);
                var tot_prices = Number(discounts * gst / 100) + Number(discounts);
                // alert(disc); exit;
                
                $('#tot_'+splt_this_id_ar).val(tot_price);
                $('#tot_val_'+splt_this_id_ar).val(tot_prices);
                });
                // ON keyup gst_amt END
                // ON keyup supplier_amt
                $(document).on('keyup', '.sup_amts', function( e ) {
                   
                var this_attr_id = $.trim($(this).attr("id"));
                var splt_this_id = this_attr_id.split("_");
                var splt_this_id_ar = splt_this_id[2];

                var disc = $('#disc_amt_'+splt_this_id_ar).val();
                var price = $('#sup_amt_'+splt_this_id_ar).val();
                var prices = $('#sup_amt_'+splt_this_id_ar).val()*$('#iqty_'+splt_this_id_ar).val();
                var dec = (disc / 100).toFixed(2); //its convert 10 into 0.10
                //alert(dec);
                var mult = price * dec;
                var mults = prices * dec; // gives the value for subtract from main value
                var discount = price - mult;
                var discounts = prices - mults;
                
                var gst = $('#gst_amt_'+splt_this_id_ar).val();
                var tot_price = Number(discount * gst / 100) + Number(discount);
                var tot_prices = Number(discounts * gst / 100) + Number(discounts);
                // alert(disc); exit;
                
                $('#tot_'+splt_this_id_ar).val(tot_price);
                $('#tot_val_'+splt_this_id_ar).val(tot_prices);
                });
	});
</script>
<script>
	jQuery(function ($) {
    //form submit handler
    $('#store_list').submit(function (e) {
        //check atleat 1 checkbox is checked
        if (!$('.chk').is(':checked')) {
            //prevent the default form submit if it is not checked
            alert("Plz select The Supplier Amouunt")
            e.preventDefault();
        }
       
       
    })
})
	</script>
    <script>
        $(document).on('click', '.edits', function( e ) {
                //var this_val = $.trim($("#quo_no").val());
                var this_attr_id = $.trim($(this).attr("id"));
                var splt_this_id = this_attr_id.split("_");
                var splt_this_id_ar = splt_this_id[1];
                //alert(splt_this_id_ar); exit;
                $('#sup_amt_'+splt_this_id_ar).attr("readonly", false); 
                $('#gst_amt_'+splt_this_id_ar).attr("readonly", false); 
                $('#disc_amt_'+splt_this_id_ar).attr("readonly", false); 
                $('#editing_'+splt_this_id_ar).toggle();
                document.getElementById("end-editing_"+splt_this_id_ar).style.visibility = 'visible';
                document.getElementById("edit-button_"+splt_this_id_ar).style.visibility = 'hidden';


                });

                $(document).on('click', '.done', function( e ) {
                //var this_val = $.trim($("#quo_no").val());
                var this_attr_id = $.trim($(this).attr("id"));
                var splt_this_id = this_attr_id.split("_");
                var splt_this_id_ar = splt_this_id[1];
                $('#sup_amt'+splt_this_id_ar).attr("readonly", true); 
                $('#gst_amt_'+splt_this_id_ar).attr("readonly", true); 
                $('#disc_amt_'+splt_this_id_ar).attr("readonly", true); 
                document.getElementById("end-editing_"+splt_this_id_ar).style.visibility = 'hidden';
                document.getElementById("edit-button_"+splt_this_id_ar).style.visibility = 'visible';

                });

                
        </script>